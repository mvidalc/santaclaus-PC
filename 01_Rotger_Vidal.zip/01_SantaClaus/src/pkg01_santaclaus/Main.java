/*
 * Miquel Vidal Coll i Toni Rotger López
 * Primer lliurament de programació concurrent
 * El problema de Santa Claus 
 *
 * VIDEO: https://youtu.be/KlC84SAp35o
 * 
 */
package pkg01_santaclaus;

import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Miguel Vidal i Toni Rotger
 */
public class Main implements Runnable {
    
    static Thread[] threads = new Thread[19];
    private final Ren[] arrayRens = new Ren[9];
    private final Elf[] arrayElfs = new Elf[9];
    
    public static Semaphore mutexSanta = new Semaphore(0);
    public static Semaphore mutexElfs = new Semaphore(0);
    public static Semaphore mutexRens = new Semaphore(0);
    
    
    
    static Random r = new Random();
    
    private String[] Elfs = {"Pedro", "Josemi", "Eusebio", "Martín", "Aurora",
        "Pau", "Elisa", "Toni", "Javier", "Miguel", "Sara", "Manel",
         "Patricia", "Adrián", "Aina", "Fidel", "Aarón", "Ismael"};
    
    private String[] Rens = {"Rudolph", "Dasher", "Dancer", "Prancer",
        "Vixen", "Comet", "Cupid", "Donner", "Blitzen"};
    
    /*
    Mètode principal del programa
    */
    public void inicio(){
        
        desordenar(Elfs);
        crearRens();
        crearElfs();
        threads[0] = new Thread(new Santa("Santa Claus", 0));
        prepararThreads();
        
    }
    
        @Override
    public void run() {
        
    }
    
    /*
    Algoritme de shuffle de Fisher-Yates
    vist a programació 2
    */
    private void desordenar(String[] nom) {
        
       int n = nom.length;
       
        for (int i = 0; i < n ; i++) {
            int random = i + r.nextInt(n-i);
            String aux = nom[random];
            nom[random] = nom[i];
            nom[i] = aux;
        }
    }
    
    private void crearRens(){
        for (int i = 0; i < arrayRens.length; i++) {
            arrayRens[i] = new Ren(Rens[i]);
        }
    }
    
    private void crearElfs(){
        for (int i = 0; i < arrayElfs.length; i++) {
            arrayElfs[i] = new Elf(Elfs[i],0);
        }
    }
    
    private void prepararThreads() {
        int i = 1;
        for (int j = 0; j < arrayRens.length; j++) {
            threads[i] = new Thread(arrayRens[j]);
            i++;
        }
        for (int j = 0; j < arrayElfs.length; j++) {
            threads[i] = new Thread(arrayElfs[j]);
            i++;
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Main m = new Main();
        m.inicio();
        
        for (int i = 0; i < threads.length; i++) {
            threads[i].start();
        }
        
        for (int i = 0; i < threads.length; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
}
