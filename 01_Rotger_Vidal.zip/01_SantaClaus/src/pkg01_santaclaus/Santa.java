
package pkg01_santaclaus;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Miguel Vidal
 */
public class Santa implements Runnable {

    String nom;
    private static int vegadesAjuda;
    private int rensFermats;
    final int id = 0;

    public Santa(String nom, int vegadesAjuda) {
        this.nom = nom;
        this.vegadesAjuda = vegadesAjuda;
    }

    public String getNom() {
        return nom;
    }

    public static int getVegadesAjuda() {
        return vegadesAjuda;
    }

    public void ajuda() {
        this.vegadesAjuda++;
    }
    
    public static boolean maximAjudat(){
        return Santa.vegadesAjuda == 6;
    }

    @Override
    public String toString() {
        return "Santa(" + "nom = " + nom + ", vegadesAjuda = " + vegadesAjuda + ", id = " + id + ')';
    }

    @Override
    public void run() {

        System.out.println("Ho ho ho soy " + this.getNom());

        while ((this.getVegadesAjuda() < 6) || (rensFermats < 9)) {

            try {

                Main.mutexSanta.acquire();

                if ((Elf.getElfsEsperant() == 3) && (!this.maximAjudat()) ) {

                    System.out.println(this.getNom() + ": Voy a ayudar a los elfos");
                    
                    for (int i = 0; i < Elf.getElfsEsperant(); i++) {
                           
                        Thread.sleep(3000);
                        Main.mutexElfs.release();
                        
                    }

                    this.ajuda();
                    System.out.println(this.getNom() + ": He ayudado " + this.getVegadesAjuda() + " veces.");
                    Elf.mutexElfsCoa.release(3);
                    Elf.setElfsEsperant(0);
                    Elf.mutexContador.release();
                    
                    
                } else if (Ren.getNumRens() == 9) {

                    System.out.println(this.getNom() + ": Voy a atar a los renos");
                    Thread.sleep(1500);
                    for (int i = 1; i <= Ren.getNumRens(); i++) {
                        Thread.sleep(2000);
                        System.out.println(this.getNom() + ": Reno numero " + (i) + " atado!");
                        Thread.sleep(3000);
                        Main.mutexRens.release();

                        
                    }
                    rensFermats=9;  
                    Ren.setNumRens(0);

                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Santa.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
       
        System.out.println(this.getNom() + ": Feliz Navidad! Hasta el año que viene!");
    }
}
