
package pkg01_santaclaus;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import static pkg01_santaclaus.Main.mutexSanta;
import static pkg01_santaclaus.Main.mutexRens;

/**
 *
 * @author Miguel Vidal
 */
public class Ren implements Runnable {

    String nom;
    final int id = 2;
    private static volatile int numRens;
    static Semaphore mutexContador = new Semaphore(1);

    public Ren(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }
    
    public static int getNumRens(){
        return numRens;
    }
    
    public static void setNumRens(int rens){
        numRens = rens;
    }

    @Override
    public String toString() {
        return "Ren(" + "nom = " + nom + ", id = " + id + ')';
    }

    @Override
    public void run() {

        try {
            
            System.out.println("    Hola soy el Reno " + this.getNom());
            Thread.sleep(2000);
            mutexContador.acquire();
            numRens++;
            
            if (numRens < 9) {
                Thread.sleep(7000);
                System.out.println("    " + this.getNom() + " LISTO!");

            } else {
                Thread.sleep(7000);  
                System.out.println("    " + this.getNom() + " LISTO!");
                System.out.println("    Estamos todos listos! Dice " + this.getNom());
                mutexSanta.release();

            }
           
            mutexContador.release();
            
            mutexRens.acquire();
            
            System.out.println("    " + this.getNom() + ": He acabado santa, me voy a dormir");
            

        } catch (InterruptedException ex) {
            Logger.getLogger(Ren.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
