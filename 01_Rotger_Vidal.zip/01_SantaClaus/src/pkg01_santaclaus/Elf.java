
package pkg01_santaclaus;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import static pkg01_santaclaus.Main.mutexElfs;
import static pkg01_santaclaus.Main.mutexSanta;

/**
 *
 * @author Miguel Vidal
 */
public class Elf implements Runnable {

    String nom;
    volatile int vegadesAjudat;
    final int id = 1;
    private static volatile int contadorElfs;
    static Semaphore mutexElfsCoa = new Semaphore(3);
    static Semaphore mutexContador = new Semaphore(1);

    public Elf(String nom, int vegadesAjudat) {
        this.nom = nom;
        this.vegadesAjudat = vegadesAjudat;
    }

    private String getNom() {
        return this.nom;
    }

    public void demanaAjuda() {
        this.vegadesAjudat++;
    }

    public boolean elfLlest() {
        return this.vegadesAjudat == 2;
    }

    public static int getElfsEsperant() {
        return contadorElfs;
    }

    public static void setElfsEsperant(int elfs) {
        contadorElfs = elfs;
    }

    @Override
    public String toString() {
        return "Elf(" + "nom = " + nom + ", vegadesAjudat = " + vegadesAjudat + ", id = " + id + ')';
    }

    @Override
    public void run() {
        try {
            
            System.out.println("        Hola soy el Elfo " + this.getNom());
            Thread.sleep(2000);
            
            while (!this.elfLlest()) {
                
                
                    
                    
                    Thread.sleep(2000);
                    mutexElfsCoa.acquire();
                    mutexContador.acquire();
                    contadorElfs++;
                    
                    if (contadorElfs < 3) {
                        
                        System.out.println("        " + this.getNom() + ": Santa ayudame por favor");
                        System.out.println("   Ahora mismo hay " + contadorElfs + " elfos pidiendo ayuda");
                        Thread.sleep(2000);
                        mutexContador.release();
                        
                    } else {
                        
                        System.out.println("        " + this.getNom() + ": Santa ayudame por favor, somos 3 ESTAMOS LISTOS");
                        Thread.sleep(2000);
                        mutexSanta.release();
                        
                    }
                    
                    mutexElfs.acquire();
                    this.demanaAjuda();
                    System.out.println("        " + this.nom + " ha sido ayudado. Lleva " +this.vegadesAjudat+" ayuda/s hoy");
                    
                
            }
            System.out.println("        " + this.nom + ": Gracias Santa, me voy!");
        } catch (InterruptedException ex) {
            Logger.getLogger(Elf.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
